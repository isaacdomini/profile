#Cyriac Domini Thundathil
#CSE 3461 Lab 2
#Client
#02/07/2017

import sys
import io
import os
import socket
#checks number of parameters input
if(len(sys.argv) != 4):
  print("Unknown format. Use: python3 ftpc.py <remoteip> <remoteport> <filename>")
  sys.exit()

#host, port and filename from args
host = str(sys.argv[1])
port = int(sys.argv[2])
filename = str(sys.argv[3])


#Setup server connection
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
print ('Connected to ', host, ':', port)

#open file
inputFile = open(filename, 'rb')

#send size of file in 4 bytes
fileSize = str(os.stat(filename).st_size)
if len(fileSize.encode('utf-8')) > 4:
    print("Encoded filesize size is greater that 4 bytes. Trimming file name")
    fileSize = fileSize[-4:]
else:
    fillerSize = 4 - len(fileSize.encode('utf-8'))
    while fillerSize > 0:
        fileSize += ' '
        fillerSize -= 1
s.sendall(fileSize.encode('utf-8'))

#send filename
if len(filename.encode('utf-8')) > 20:
    print("Encoded filename size is greater that 20 bytes")
    sys.exit()
else:
    fillerSize = 20 - len(filename.encode('utf-8'))
    while fillerSize > 0:
        filename += ' '
        fillerSize -= 1
s.sendall(filename.encode('utf-8'))

#copys from input file and writes to output file
counter = 0;
while True:
    data = inputFile.read(1000)
    if not data:
        break

    s.sendall(data)
    counter += 1

print("Success! File copied!")

#closes files
inputFile.close()
