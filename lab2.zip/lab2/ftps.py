#Cyriac Domini Thundathil
#CSE 3461 Lab 2
#Server
#02/07/2017

import sys
import io
import os
import socket
#checks number of parameters input
if(len(sys.argv) != 2):
  print("Unknown format. Use: python3 ftps.py <PORT>")
  sys.exit()

#host and port
host = ''
port = int(sys.argv[1])

#Setup server connection
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host, port))
s.listen(1)
conn, addr = s.accept();
print ('Connection accepted by ', addr)


#created recv directory if it does not exist
if not os.path.exists("recv"):
  os.makedirs("recv")

#Consume first 4 bytes (bytes to follow)
data = conn.recv(4)
print ("Size: ", data.decode('utf-8'))
filename = conn.recv(20).decode('utf-8').strip()
print ("Filename: ", filename)

#sets up input and output files
outputFile = open("recv/"+filename,"wb")

#copys from input file and writes to output file
counter = 0;
while True:
  data = conn.recv(1000)
  if not data:
    break
  outputFile.write(data)
  counter += 1

print("Success! File copied!")

#closes files
conn.close()
outputFile.close()
#
# #opens files again
# outputFile = open("recv/"+sys.argv[1],"rb")
# inputFile = open(sys.argv[1], "rb")
#
# #create md5 hash of both files
# inputHash = hashlib.md5()
# outputHash = hashlib.md5()
# for i in range(1,counter):
#
#   inputHash.update(inputFile.read(1000))
#   outputHash.update(outputFile.read(1000))
#
# #compare hashes
# if(inputHash.hexdigest()==outputHash.hexdigest()):
#     print("Files are bitwise identical")
#
# #closes files
# inputFile.close()
# outputFile.close()
