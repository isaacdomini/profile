Cyriac Domini Thundathil
Thundathil.4
12:45 section
CSE 3461
To run:
on server, run:
python3 ftps.py <portnumber>

then on the client
python3 ftpc.py <remoteip> <portnumber> <filename>

<filename> is the file you want to copy.
<remoteip> is the ip address of the server
<portnumber> is the port number
Expected behavior:
copies <filename> from client to recv/<filename> in the server
and both files are bitwise identical
